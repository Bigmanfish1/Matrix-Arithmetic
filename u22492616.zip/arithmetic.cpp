#include "arithmetic.h"
using namespace std;

Arithmetic::Arithmetic(){

}

Arithmetic::~Arithmetic(){

}

Arithmetic::Arithmetic(const Arithmetic& rhs){
    
}